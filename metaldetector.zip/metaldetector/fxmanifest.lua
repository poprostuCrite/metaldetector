name 'Prospecting'
author 'glitchdetector'
contact 'glitchdetector@gmail.com'

fx_version 'adamant'
game 'gta5'

data_file 'DLC_ITYP_REQUEST' 'gen_w_am_metaldetector.ytyp'